function validate(e)
{
   
    if (formHasErrors()==false) {
		
		// Prevents the form from submitting
		e.preventDefault();

		// When using onSubmit="validate()" in markup, returning false would prevent
		// the form from submitting
		return false;
	}

	// When using onSubmit="validate()" in markup, returning true would allow
	// the form to submit
	
	return true;

}
function hideErrors()
{
    document.getElementById("nameerror").style.visibility="hidden"
    document.getElementById("contacterror").style.visibility="hidden"
    document.getElementById("emailerror").style.visibility="hidden"
}
function formHasErrors()
{
    var username=document.getElementById("name").value
    hideErrors();
    var val=true;
    if (username=="")
    {
    
        document.getElementById("nameerror").style.visibility="visible"
        val=false
        
    }
    var contactno=document.getElementById("contactno").value
    var regex1=/\D/g;
    if (contactno.length<10 || regex1.test(contactno)==true)
    {
       
        document.getElementById("contacterror").style.visibility="visible"
        val=false
    }
    var email=document.getElementById("email").value
    var regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    //Matching the given phone number with regular expression
    var result = regex.test(email);
    if(result==false) {
        document.getElementById("emailerror").style.visibility="visible"
        val=false  
    }
    
    return val;
}
function load()
{

document.getElementById("form1").addEventListener('submit', validate);

}



document.addEventListener("DOMContentLoaded", load);